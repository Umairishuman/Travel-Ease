﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TravelEaseApp.ServiceProvider
{
    public partial class servicesForm : Form
    {
        public servicesForm()
        {
            InitializeComponent();
        }

        private void servicesForm_Load(object sender, EventArgs e)
        {
            AddPlaceholder(textBox1, "1");
        }

        private void AddPlaceholder(TextBox textBox, string placeholderText)
        {
            textBox.Text = placeholderText;
            textBox.ForeColor = Color.Gray;

            textBox.GotFocus += (sender, e) =>
            {
                if (textBox.Text == placeholderText)
                {
                    textBox.Text = "";
                    textBox.ForeColor = Color.Black;
                    //set it to not bold
                    textBox.ForeColor = Color.Black;
                    //textBox.Font = new Font(textBox.Font, FontStyle.Regular);
                }
            };

            textBox.LostFocus += (sender, e) =>
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    textBox.Text = placeholderText;
                    textBox.ForeColor = Color.Gray;
                }
            };
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
