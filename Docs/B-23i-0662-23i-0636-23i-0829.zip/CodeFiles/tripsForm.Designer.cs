﻿namespace TravelEaseApp.TourOperator
{
    partial class tripsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            panel6 = new Panel();
            textBox1 = new TextBox();
            panel3 = new Panel();
            linkLabel2 = new LinkLabel();
            panel4 = new Panel();
            linkLabel1 = new LinkLabel();
            panel5 = new Panel();
            label1 = new Label();
            flowLayoutPanel2 = new FlowLayoutPanel();
            panel7 = new Panel();
            label8 = new Label();
            panel8 = new Panel();
            label9 = new Label();
            panel9 = new Panel();
            label10 = new Label();
            panel10 = new Panel();
            label11 = new Label();
            panel11 = new Panel();
            label12 = new Label();
            panel12 = new Panel();
            label13 = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel6.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            flowLayoutPanel2.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            panel9.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            panel12.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // label7
            // 
            label7.Location = new Point(0, 8);
            label7.Name = "label7";
            label7.Size = new Size(65, 23);
            label7.TabIndex = 1;
            label7.Text = "EDate";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.Location = new Point(0, 8);
            label6.Name = "label6";
            label6.Size = new Size(65, 23);
            label6.TabIndex = 1;
            label6.Text = "SDate";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.Location = new Point(0, 8);
            label5.Name = "label5";
            label5.Size = new Size(65, 23);
            label5.TabIndex = 1;
            label5.Text = "SLocation";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.Location = new Point(0, 8);
            label4.Name = "label4";
            label4.Size = new Size(65, 23);
            label4.TabIndex = 1;
            label4.Text = "Desc";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.Location = new Point(0, 8);
            label3.Name = "label3";
            label3.Size = new Size(65, 23);
            label3.TabIndex = 1;
            label3.Text = "Title";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.Location = new Point(0, 8);
            label2.Name = "label2";
            label2.Size = new Size(65, 23);
            label2.TabIndex = 1;
            label2.Text = "TripId";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label2);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(84, 37);
            panel1.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label3);
            panel2.Location = new Point(93, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(84, 37);
            panel2.TabIndex = 2;
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(label7);
            panel6.Location = new Point(453, 3);
            panel6.Name = "panel6";
            panel6.Size = new Size(84, 37);
            panel6.TabIndex = 6;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Control;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Location = new Point(562, 603);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(15, 16);
            textBox1.TabIndex = 8;
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.WordWrap = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(label4);
            panel3.Location = new Point(183, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(84, 37);
            panel3.TabIndex = 3;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.Location = new Point(583, 602);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(15, 15);
            linkLabel2.TabIndex = 7;
            linkLabel2.TabStop = true;
            linkLabel2.Text = ">";
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(label5);
            panel4.Location = new Point(273, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(84, 37);
            panel4.TabIndex = 4;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(541, 602);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(15, 15);
            linkLabel1.TabIndex = 5;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "<";
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(label6);
            panel5.Location = new Point(363, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(84, 37);
            panel5.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            label1.Location = new Point(492, 29);
            label1.Name = "label1";
            label1.Size = new Size(97, 46);
            label1.TabIndex = 6;
            label1.Text = "Trips";
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(panel1);
            flowLayoutPanel2.Controls.Add(panel2);
            flowLayoutPanel2.Controls.Add(panel3);
            flowLayoutPanel2.Controls.Add(panel4);
            flowLayoutPanel2.Controls.Add(panel5);
            flowLayoutPanel2.Controls.Add(panel6);
            flowLayoutPanel2.Controls.Add(panel7);
            flowLayoutPanel2.Controls.Add(panel8);
            flowLayoutPanel2.Controls.Add(panel9);
            flowLayoutPanel2.Controls.Add(panel10);
            flowLayoutPanel2.Controls.Add(panel11);
            flowLayoutPanel2.Controls.Add(panel12);
            flowLayoutPanel2.Location = new Point(3, 3);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(1091, 40);
            flowLayoutPanel2.TabIndex = 0;
            // 
            // panel7
            // 
            panel7.BackColor = Color.White;
            panel7.Controls.Add(label8);
            panel7.Location = new Point(543, 3);
            panel7.Name = "panel7";
            panel7.Size = new Size(84, 37);
            panel7.TabIndex = 7;
            // 
            // label8
            // 
            label8.Location = new Point(0, 8);
            label8.Name = "label8";
            label8.Size = new Size(65, 23);
            label8.TabIndex = 1;
            label8.Text = "Duration";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            panel8.BackColor = Color.White;
            panel8.Controls.Add(label9);
            panel8.Location = new Point(633, 3);
            panel8.Name = "panel8";
            panel8.Size = new Size(84, 37);
            panel8.TabIndex = 8;
            // 
            // label9
            // 
            label9.Location = new Point(0, 8);
            label9.Name = "label9";
            label9.Size = new Size(65, 23);
            label9.TabIndex = 1;
            label9.Text = "Capacity";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel9
            // 
            panel9.BackColor = Color.White;
            panel9.Controls.Add(label10);
            panel9.Location = new Point(723, 3);
            panel9.Name = "panel9";
            panel9.Size = new Size(84, 37);
            panel9.TabIndex = 9;
            // 
            // label10
            // 
            label10.Location = new Point(0, 8);
            label10.Name = "label10";
            label10.Size = new Size(65, 23);
            label10.TabIndex = 1;
            label10.Text = "Status";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel10
            // 
            panel10.BackColor = Color.White;
            panel10.Controls.Add(label11);
            panel10.Location = new Point(813, 3);
            panel10.Name = "panel10";
            panel10.Size = new Size(84, 37);
            panel10.TabIndex = 10;
            // 
            // label11
            // 
            label11.Location = new Point(0, 8);
            label11.Name = "label11";
            label11.Size = new Size(65, 23);
            label11.TabIndex = 1;
            label11.Text = "Category";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            panel11.BackColor = Color.White;
            panel11.Controls.Add(label12);
            panel11.Location = new Point(903, 3);
            panel11.Name = "panel11";
            panel11.Size = new Size(84, 37);
            panel11.TabIndex = 11;
            // 
            // label12
            // 
            label12.Location = new Point(0, 8);
            label12.Name = "label12";
            label12.Size = new Size(65, 23);
            label12.TabIndex = 1;
            label12.Text = "perPrice";
            label12.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel12
            // 
            panel12.BackColor = Color.White;
            panel12.Controls.Add(label13);
            panel12.Location = new Point(993, 3);
            panel12.Name = "panel12";
            panel12.Size = new Size(84, 37);
            panel12.TabIndex = 12;
            // 
            // label13
            // 
            label13.Location = new Point(0, 8);
            label13.Name = "label13";
            label13.Size = new Size(65, 23);
            label13.TabIndex = 1;
            label13.Text = "Image";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(flowLayoutPanel2);
            flowLayoutPanel1.Location = new Point(20, 90);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1094, 512);
            flowLayoutPanel1.TabIndex = 9;
            // 
            // tripsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1134, 649);
            Controls.Add(textBox1);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Controls.Add(label1);
            Controls.Add(flowLayoutPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "tripsForm";
            Text = "Form1";
            Load += tripsForm_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            flowLayoutPanel2.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel9.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel11.ResumeLayout(false);
            panel12.ResumeLayout(false);
            flowLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Panel panel1;
        private Panel panel2;
        private Panel panel6;
        private TextBox textBox1;
        private Panel panel3;
        private LinkLabel linkLabel2;
        private Panel panel4;
        private LinkLabel linkLabel1;
        private Panel panel5;
        private Label label1;
        private FlowLayoutPanel flowLayoutPanel2;
        private Panel panel7;
        private Label label8;
        private Panel panel8;
        private Label label9;
        private FlowLayoutPanel flowLayoutPanel1;
        private Panel panel9;
        private Label label10;
        private Panel panel10;
        private Label label11;
        private Panel panel11;
        private Label label12;
        private Panel panel12;
        private Label label13;
    }
}