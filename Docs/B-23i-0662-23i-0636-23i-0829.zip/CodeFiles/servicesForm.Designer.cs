﻿namespace TravelEaseApp.ServiceProvider
{
    partial class servicesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            linkLabel1 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            textBox1 = new TextBox();
            flowLayoutPanel1 = new FlowLayoutPanel();
            flowLayoutPanel2 = new FlowLayoutPanel();
            panel1 = new Panel();
            label2 = new Label();
            panel2 = new Panel();
            label3 = new Label();
            panel3 = new Panel();
            label4 = new Label();
            panel4 = new Panel();
            label5 = new Label();
            panel5 = new Panel();
            label6 = new Label();
            panel6 = new Panel();
            label7 = new Label();
            flowLayoutPanel1.SuspendLayout();
            flowLayoutPanel2.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            label1.Location = new Point(484, 25);
            label1.Name = "label1";
            label1.Size = new Size(149, 46);
            label1.TabIndex = 1;
            label1.Text = "Services";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(533, 598);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(15, 15);
            linkLabel1.TabIndex = 0;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "<";
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.Location = new Point(575, 598);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(15, 15);
            linkLabel2.TabIndex = 2;
            linkLabel2.TabStop = true;
            linkLabel2.Text = ">";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Control;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Location = new Point(554, 599);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(15, 16);
            textBox1.TabIndex = 3;
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.WordWrap = false;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(flowLayoutPanel2);
            flowLayoutPanel1.Location = new Point(12, 86);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1094, 512);
            flowLayoutPanel1.TabIndex = 4;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(panel1);
            flowLayoutPanel2.Controls.Add(panel2);
            flowLayoutPanel2.Controls.Add(panel3);
            flowLayoutPanel2.Controls.Add(panel4);
            flowLayoutPanel2.Controls.Add(panel5);
            flowLayoutPanel2.Controls.Add(panel6);
            flowLayoutPanel2.Location = new Point(3, 3);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(1091, 40);
            flowLayoutPanel2.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label2);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(175, 37);
            panel1.TabIndex = 1;
            // 
            // label2
            // 
            label2.Location = new Point(0, 8);
            label2.Name = "label2";
            label2.Size = new Size(175, 23);
            label2.TabIndex = 1;
            label2.Text = "ServiceId";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label3);
            panel2.Location = new Point(184, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(175, 37);
            panel2.TabIndex = 2;
            // 
            // label3
            // 
            label3.Location = new Point(0, 8);
            label3.Name = "label3";
            label3.Size = new Size(175, 23);
            label3.TabIndex = 1;
            label3.Text = "ServiceType";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(label4);
            panel3.Location = new Point(365, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(175, 37);
            panel3.TabIndex = 3;
            // 
            // label4
            // 
            label4.Location = new Point(0, 8);
            label4.Name = "label4";
            label4.Size = new Size(175, 23);
            label4.TabIndex = 1;
            label4.Text = "ServiceDescription";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(label5);
            panel4.Location = new Point(546, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(175, 37);
            panel4.TabIndex = 4;
            // 
            // label5
            // 
            label5.Location = new Point(0, 8);
            label5.Name = "label5";
            label5.Size = new Size(175, 23);
            label5.TabIndex = 1;
            label5.Text = "PricePerPerson";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(label6);
            panel5.Location = new Point(727, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(175, 37);
            panel5.TabIndex = 5;
            // 
            // label6
            // 
            label6.Location = new Point(0, 8);
            label6.Name = "label6";
            label6.Size = new Size(175, 23);
            label6.TabIndex = 1;
            label6.Text = "Capacity";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(label7);
            panel6.Location = new Point(908, 3);
            panel6.Name = "panel6";
            panel6.Size = new Size(175, 37);
            panel6.TabIndex = 6;
            // 
            // label7
            // 
            label7.Location = new Point(0, 8);
            label7.Name = "label7";
            label7.Size = new Size(175, 23);
            label7.TabIndex = 1;
            label7.Text = "ProviderId";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // servicesForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1118, 610);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(textBox1);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "servicesForm";
            Text = "Form1";
            Load += servicesForm_Load;
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel6.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private LinkLabel linkLabel1;
        private LinkLabel linkLabel2;
        private TextBox textBox1;
        private FlowLayoutPanel flowLayoutPanel1;
        private FlowLayoutPanel flowLayoutPanel2;
        private Panel panel1;
        private Label label2;
        private Panel panel2;
        private Label label3;
        private Panel panel3;
        private Label label4;
        private Panel panel4;
        private Label label5;
        private Panel panel5;
        private Label label6;
        private Panel panel6;
        private Label label7;
    }
}